__mod_name__ = "Mᴜsɪᴄ"

__help__ = """
 ❍ /song <song name>*:* Uploads the song in it's best quality available
 💡Ex: `/song Faded Alan Walker`
"""
